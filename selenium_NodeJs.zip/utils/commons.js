const {
    Builder,
    By,
    until
} = require('selenium-webdriver');
let Page = require('../lib/basePage');
class Commons {
    // Utility functions

}

module.exports = new Commons();